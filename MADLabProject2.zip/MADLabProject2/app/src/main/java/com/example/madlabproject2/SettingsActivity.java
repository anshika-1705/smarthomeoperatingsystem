package com.example.madlabproject2;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private EditText apiKeyEditText;
    private EditText serverUrlEditText;
    private Switch darkModeSwitch;
    private Switch notificationsSwitch;
    private Switch autoDashboardUpdateSwitch;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Set up the action bar with back button
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Settings");
        }

        // Initialize views
        apiKeyEditText = findViewById(R.id.apiKeyEditText);
        serverUrlEditText = findViewById(R.id.serverUrlEditText);
        darkModeSwitch = findViewById(R.id.darkModeSwitch);
        notificationsSwitch = findViewById(R.id.notificationsSwitch);
        autoDashboardUpdateSwitch = findViewById(R.id.autoDashboardUpdateSwitch);
        saveButton = findViewById(R.id.saveSettingsButton);

        // Load saved settings (mock for now)
        loadSettings();

        // Set save button click listener
        saveButton.setOnClickListener(v -> {
            saveSettings();
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void loadSettings() {
        // In a real app, you would load from SharedPreferences
        apiKeyEditText.setText("YOUR_API_KEY_HERE");
        serverUrlEditText.setText("https://api.smarthome.example.com");
        darkModeSwitch.setChecked(false);
        notificationsSwitch.setChecked(true);
        autoDashboardUpdateSwitch.setChecked(true);
    }

    private void saveSettings() {
        // In a real app, you would save to SharedPreferences
        String apiKey = apiKeyEditText.getText().toString();
        String serverUrl = serverUrlEditText.getText().toString();
        boolean darkMode = darkModeSwitch.isChecked();
        boolean notifications = notificationsSwitch.isChecked();
        boolean autoDashboardUpdate = autoDashboardUpdateSwitch.isChecked();

        // Here you would save these settings to SharedPreferences
    }
}
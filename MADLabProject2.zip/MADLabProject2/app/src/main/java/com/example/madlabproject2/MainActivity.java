package com.example.madlabproject2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
    private GridLayout roomsGrid;
    private FloatingActionButton addRoomFab;
    private ImageButton settingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        roomsGrid = findViewById(R.id.roomsGrid);
        addRoomFab = findViewById(R.id.addRoomFab);
        TextView welcomeText = findViewById(R.id.welcomeText);
        settingsButton = findViewById(R.id.settingsButton);


        // Set welcome message
        welcomeText.setText("Welcome to Smart Home Monitor");

        settingsButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        // Set FAB click listener
        addRoomFab.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddRoomActivity.class);
            startActivity(intent);
        });

        // Load saved rooms (mock data for now)
        loadMockRooms();
    }
    @Override
    protected void onResume() {
        super.onResume();
        // Refresh rooms when returning to activity
        // In a real app, you would load this from a database or shared preferences
        loadMockRooms();
    }

    private void loadMockRooms() {
        // Clear existing views
        roomsGrid.removeAllViews();

        // Add mock rooms (in a real app, this would come from storage)
        addRoomCard("Living Room", "3 sensors active");
        addRoomCard("Bedroom", "2 sensors active");
        addRoomCard("Kitchen", "4 sensors active");
        addRoomCard("Bathroom", "1 sensor active");
    }

    private void addRoomCard(String roomName, String sensorInfo) {
        View roomCard = getLayoutInflater().inflate(R.layout.room_card_layout, roomsGrid, false);

        TextView roomNameText = roomCard.findViewById(R.id.roomNameText);
        TextView sensorInfoText = roomCard.findViewById(R.id.sensorInfoText);
        Button viewDetailsBtn = roomCard.findViewById(R.id.viewDetailsBtn);

        roomNameText.setText(roomName);
        sensorInfoText.setText(sensorInfo);

        viewDetailsBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RoomDetailActivity.class);
            intent.putExtra("ROOM_NAME", roomName);
            startActivity(intent);
        });

        roomsGrid.addView(roomCard);
    }
}
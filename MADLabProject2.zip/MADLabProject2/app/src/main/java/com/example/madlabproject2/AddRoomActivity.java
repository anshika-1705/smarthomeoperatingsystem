package com.example.madlabproject2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class AddRoomActivity extends AppCompatActivity {
    private EditText roomNameEditText;
    private CheckBox temperatureCB, humidityCB, co2CB, motionCB, lightCB;
    private Button addRoomButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_room);

        // Set the title
        setTitle("Add New Room");

        // Initialize views
        roomNameEditText = findViewById(R.id.roomNameEditText);
        temperatureCB = findViewById(R.id.temperatureCB);
        humidityCB = findViewById(R.id.humidityCB);
        co2CB = findViewById(R.id.co2CB);
        motionCB = findViewById(R.id.motionCB);
        lightCB = findViewById(R.id.lightCB);
        addRoomButton = findViewById(R.id.addRoomButton);

        // Set click listener for add room button
        addRoomButton.setOnClickListener(v -> {
            // Validate room name
            String roomName = roomNameEditText.getText().toString().trim();
            if (roomName.isEmpty()) {
                roomNameEditText.setError("Room name is required");
                return;
            }

            // Check if at least one sensor is selected
            if (!temperatureCB.isChecked() && !humidityCB.isChecked() && !co2CB.isChecked()
                    && !motionCB.isChecked() && !lightCB.isChecked()) {
                Toast.makeText(this, "Please select at least one sensor", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get selected sensors
            List<String> selectedSensors = new ArrayList<>();
            if (temperatureCB.isChecked()) selectedSensors.add("Temperature");
            if (humidityCB.isChecked()) selectedSensors.add("Humidity");
            if (co2CB.isChecked()) selectedSensors.add("CO2");
            if (motionCB.isChecked()) selectedSensors.add("Motion");
            if (lightCB.isChecked()) selectedSensors.add("Light");

            // In a real app, you'd save this data to a database
            // For now, just show a success message
            Toast.makeText(this, "Room added successfully: " + roomName, Toast.LENGTH_SHORT).show();

            // Return to main activity
            finish();
        });
    }
}
package com.example.madlabproject2;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RoomDetailActivity extends AppCompatActivity {
    private TextView roomNameTextView;
    private LineChart temperatureChart, humidityChart, co2Chart;
    private LinearLayout temperatureContainer, humidityContainer, co2Container;
    private Switch lightSwitch, fanSwitch;

    private String roomName;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_detail);

        // Get room name from intent
        roomName = getIntent().getStringExtra("ROOM_NAME");
        if (roomName == null) roomName = "Unknown Room";

        // Set title
        setTitle(roomName + " Details");

        // Initialize views
        roomNameTextView = findViewById(R.id.roomNameTextView);
        temperatureContainer = findViewById(R.id.temperatureContainer);
        humidityContainer = findViewById(R.id.humidityContainer);
        co2Container = findViewById(R.id.co2Container);
        temperatureChart = findViewById(R.id.temperatureChart);
        humidityChart = findViewById(R.id.humidityChart);
        co2Chart = findViewById(R.id.co2Chart);
        lightSwitch = findViewById(R.id.lightSwitch);
        fanSwitch = findViewById(R.id.fanSwitch);

        // Set room name
        roomNameTextView.setText(roomName);

        // Set up switch listeners
        lightSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // In a real app, this would send commands to IoT devices
            String status = isChecked ? "ON" : "OFF";
            showFeedback("Light turned " + status);
        });

        fanSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // In a real app, this would send commands to IoT devices
            String status = isChecked ? "ON" : "OFF";
            showFeedback("Fan turned " + status);
        });

        // Set up charts with demo data
        setupTemperatureChart();
        setupHumidityChart();
        setupCO2Chart();

        // In a real app, you would check which sensors are actually installed in this room
        // For demo purposes, we'll show all sensors
    }

    private void setupTemperatureChart() {
        // Generate random temperature data (20-30°C)
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < 24; i++) {
            entries.add(new Entry(i, 20 + random.nextFloat() * 10));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Temperature (°C)");
        styleDataSet(dataSet, Color.RED);

        LineData lineData = new LineData(dataSet);
        setupChart(temperatureChart, lineData, "Temperature over 24 hours");
    }

    private void setupHumidityChart() {
        // Generate random humidity data (30-70%)
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < 24; i++) {
            entries.add(new Entry(i, 30 + random.nextFloat() * 40));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Humidity (%)");
        styleDataSet(dataSet, Color.BLUE);

        LineData lineData = new LineData(dataSet);
        setupChart(humidityChart, lineData, "Humidity over 24 hours");
    }

    private void setupCO2Chart() {
        // Generate random CO2 data (400-1200 ppm)
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < 24; i++) {
            entries.add(new Entry(i, 400 + random.nextFloat() * 800));
        }

        LineDataSet dataSet = new LineDataSet(entries, "CO2 (ppm)");
        styleDataSet(dataSet, Color.GREEN);

        LineData lineData = new LineData(dataSet);
        setupChart(co2Chart, lineData, "CO2 levels over 24 hours");
    }

    private void styleDataSet(LineDataSet dataSet, int color) {
        dataSet.setColor(color);
        dataSet.setCircleColor(color);
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(3f);
        dataSet.setDrawCircleHole(false);
        dataSet.setValueTextSize(9f);
        dataSet.setDrawFilled(true);
        dataSet.setFillAlpha(50);
        dataSet.setFillColor(color);
        dataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
    }

    private void setupChart(LineChart chart, LineData data, String description) {
        // X-axis setup
        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return (int)value + ":00";
            }
        });

        // Left Y-axis setup
        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setDrawGridLines(false);

        // Right Y-axis setup (disable)
        chart.getAxisRight().setEnabled(false);

        // Other chart settings
        chart.setData(data);
        chart.getDescription().setText(description);
        chart.getLegend().setEnabled(true);
        chart.setDrawGridBackground(false);
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);
        chart.animateX(1500);
        chart.invalidate();
    }

    private void showFeedback(String message) {
        // In a real app, you might want to use snackbar instead
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show();
    }
}